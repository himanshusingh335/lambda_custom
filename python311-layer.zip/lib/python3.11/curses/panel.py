"""curses.panel

Module for using panels with curses.
"""

from _curses_panel import *
